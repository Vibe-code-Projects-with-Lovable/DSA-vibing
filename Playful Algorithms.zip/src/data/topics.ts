export type Topic = {
  slug: string;
  name: string;
  emoji: string;
  blurb: string;
  story: string;
  grad: string;
};

export const dataStructures: Topic[] = [
  { slug: "array", name: "Array", emoji: "📦", blurb: "A row of toy boxes.", story: "Imagine a row of toy boxes lined up. Each box has a number so you know exactly where it is. Want box 3? Just walk to box 3 — instant!", grad: "from-brand-blue to-brand-purple" },
  { slug: "linked-list", name: "Linked List", emoji: "🔗", blurb: "A treasure hunt.", story: "Each clue points to the next clue. You don't know where they all are — you must follow them one by one.", grad: "from-brand-purple to-brand-pink" },
  { slug: "stack", name: "Stack", emoji: "🥞", blurb: "Pile of pancakes.", story: "You add pancakes on top, and you eat from the top. Last one in is the first one out!", grad: "from-brand-yellow to-brand-pink" },
  { slug: "queue", name: "Queue", emoji: "🍦", blurb: "Ice cream line.", story: "First child in line gets ice cream first. New kids join the back. Fair and square!", grad: "from-brand-blue to-brand-green" },
  { slug: "hash-table", name: "Hash Table", emoji: "📬", blurb: "Magic mailboxes.", story: "Tell the magic mailroom a name and it instantly hands you that person's letter. No searching!", grad: "from-brand-green to-brand-blue" },
  { slug: "tree", name: "Tree", emoji: "🌳", blurb: "Family tree.", story: "There's a top grandparent (root). Each person can have kids. Kids can have kids. It branches!", grad: "from-brand-green to-brand-yellow" },
  { slug: "graph", name: "Graph", emoji: "🗺️", blurb: "Cities & roads.", story: "Cities are dots, roads are lines. You can travel anywhere if a road connects them.", grad: "from-brand-pink to-brand-purple" },
  { slug: "heap", name: "Heap", emoji: "👑", blurb: "King of the mountain.", story: "The biggest (or smallest) always sits at the top. Move them and someone new climbs up.", grad: "from-brand-yellow to-brand-purple" },
];

export const algorithms: Topic[] = [
  { slug: "linear-search", name: "Linear Search", emoji: "🔍", blurb: "Check every box.", story: "Look in box 1, box 2, box 3... until you find your toy.", grad: "from-brand-blue to-brand-purple" },
  { slug: "binary-search", name: "Binary Search", emoji: "🎯", blurb: "Guess in halves.", story: "I'm thinking of 1–100. Guess 50. Too high? Try 25. Too low? Try 37. Genius!", grad: "from-brand-purple to-brand-pink" },
  { slug: "bubble-sort", name: "Bubble Sort", emoji: "🫧", blurb: "Bubbles float up.", story: "Compare two neighbors. If the bigger one is on the left, swap! Keep going till sorted.", grad: "from-brand-blue to-brand-green" },
  { slug: "selection-sort", name: "Selection Sort", emoji: "🎯", blurb: "Pick the smallest.", story: "Find the smallest toy and put it first. Then the next smallest. Repeat!", grad: "from-brand-green to-brand-yellow" },
  { slug: "insertion-sort", name: "Insertion Sort", emoji: "🃏", blurb: "Sort your cards.", story: "Like sorting cards in your hand — slide each new card into the right spot.", grad: "from-brand-yellow to-brand-pink" },
  { slug: "merge-sort", name: "Merge Sort", emoji: "🧩", blurb: "Split & combine.", story: "Split toys into two piles, sort each, then carefully merge them back together.", grad: "from-brand-pink to-brand-purple" },
  { slug: "quick-sort", name: "Quick Sort", emoji: "⚡", blurb: "Pick a leader.", story: "Pick one toy as the leader. Smaller toys go left, bigger toys go right. Repeat!", grad: "from-brand-purple to-brand-blue" },
  { slug: "bfs", name: "Breadth-First Search", emoji: "🌊", blurb: "Explore in waves.", story: "Look at all your neighbors first, then their neighbors. Like ripples in a pond.", grad: "from-brand-blue to-brand-pink" },
  { slug: "dfs", name: "Depth-First Search", emoji: "🕳️", blurb: "Dive deep.", story: "Pick a tunnel and follow it to the end before trying another. Brave explorer!", grad: "from-brand-purple to-brand-yellow" },
];