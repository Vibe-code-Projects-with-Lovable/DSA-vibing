export type Quiz = { q: string; opts: string[]; answer: number; why: string };

export type TopicContent = {
  why: string;
  how: string;
  real: string;
  code: string;
  bigO?: { op: string; cx: string }[];
  quiz: Quiz;
};

export const content: Record<string, TopicContent> = {
  "array": {
    why: "Arrays let you grab any item instantly if you know its number. Super fast lookups!",
    how: "Items live next to each other in memory. Each item has an index starting at 0.",
    real: "A row of mailboxes in an apartment building. Box #5 is always in the same spot.",
    code: `const toys = ["car", "doll", "block"];\ntoys.push("ball");      // add to end\nconst first = toys[0]; // grab by index\ntoys.pop();            // remove last`,
    bigO: [{op:"Read by index", cx:"O(1)"}, {op:"Add at end", cx:"O(1)"}, {op:"Search", cx:"O(n)"}],
    quiz: { q: "What's the index of the FIRST item in an array?", opts:["1","0","-1"], answer:1, why:"Arrays start counting from 0!" },
  },
  "linked-list": {
    why: "You can add or remove anywhere without shuffling everyone over.",
    how: "Each node has a value and a pointer to the next node.",
    real: "A treasure hunt: each clue tells you where the next clue is hidden.",
    code: `class Node { constructor(v){ this.v = v; this.next = null; } }\nconst a = new Node(1); a.next = new Node(2);\na.next.next = new Node(3);`,
    bigO: [{op:"Insert at head", cx:"O(1)"}, {op:"Search", cx:"O(n)"}],
    quiz: { q: "Why use a linked list instead of an array?", opts:["Faster lookups","Easy insert/remove anywhere","Less typing"], answer:1, why:"Linked lists shine at insertions/removals anywhere." },
  },
  "stack": {
    why: "Perfect when you only care about the most recent item — undo, back button, function calls.",
    how: "Push adds on top. Pop removes from top. LIFO: Last In, First Out.",
    real: "A stack of pancakes — you always grab the top one.",
    code: `const stack = [];\nstack.push("🥞 1");\nstack.push("🥞 2");\nconst top = stack.pop(); // 🥞 2`,
    bigO: [{op:"Push", cx:"O(1)"}, {op:"Pop", cx:"O(1)"}, {op:"Peek", cx:"O(1)"}],
    quiz: { q:"Stack is...", opts:["FIFO","LIFO","Random"], answer:1, why:"Last In, First Out — like pancakes!" },
  },
  "queue": {
    why: "Fairness. First come, first served. Great for tasks, printers, messages.",
    how: "Enqueue adds at back, dequeue removes from front. FIFO: First In, First Out.",
    real: "Kids in line waiting for ice cream.",
    code: `const q = [];\nq.push("Alice");  // enqueue\nq.push("Bob");\nconst next = q.shift(); // dequeue → Alice`,
    bigO: [{op:"Enqueue", cx:"O(1)"}, {op:"Dequeue", cx:"O(1)"}],
    quiz: { q:"Who gets served first?", opts:["Last to arrive","First to arrive","Tallest"], answer:1, why:"First In, First Out!" },
  },
  "hash-table": {
    why: "Lightning-fast lookups by key. Used everywhere — dictionaries, caches, databases.",
    how: "A hash function turns the key into an index, so we know where to look instantly.",
    real: "School mailroom: tell them a name, they hand you the letter without searching.",
    code: `const ages = {};\nages["John"] = 10;\nages["Lisa"] = 7;\nconsole.log(ages["John"]); // 10`,
    bigO: [{op:"Lookup", cx:"O(1) avg"}, {op:"Insert", cx:"O(1) avg"}],
    quiz: { q:"Looking up a value by key is...", opts:["Super slow","Super fast","Same as array"], answer:1, why:"Hash tables give average O(1) — instant!" },
  },
  "tree": {
    why: "Great for hierarchies: files, family, comments, the DOM.",
    how: "One root node. Each node can have children. No cycles.",
    real: "A family tree, or the folders on your computer.",
    code: `const tree = { v: "root", c: [\n  { v: "a", c: [] },\n  { v: "b", c: [{ v: "c", c: [] }] }\n]};`,
    quiz: { q:"The very top node is called the...", opts:["Leaf","Root","Branch"], answer:1, why:"The root is the topmost node." },
  },
  "graph": {
    why: "Models any network: roads, friends, the internet, dependencies.",
    how: "A set of nodes (vertices) and edges (connections). Can be directed or undirected.",
    real: "Cities connected by roads, or your friends on social media.",
    code: `const graph = {\n  A: ["B", "C"],\n  B: ["A", "D"],\n  C: ["A"],\n  D: ["B"]\n};`,
    quiz: { q:"In a graph, an edge is...", opts:["A node","A connection","A value"], answer:1, why:"Edges connect two nodes." },
  },
  "heap": {
    why: "Always grab the biggest (or smallest) thing FAST. Used in priority queues.",
    how: "A binary tree where every parent is larger (max-heap) or smaller (min-heap) than its kids.",
    real: "The king of the mountain — biggest always on top!",
    code: `// JS doesn't have built-in heap, but conceptually:\nconst heap = [9, 7, 8, 3, 5, 1]; // root = 9 (max)\n// Push & sink/swim to maintain order`,
    quiz: { q:"In a max-heap, the largest item is...", opts:["At root","At a leaf","Random"], answer:0, why:"Always at the root!" },
  },

  "linear-search": {
    why: "Simplest possible search. Works on any list, sorted or not.",
    how: "Walk through items one by one until you find the match (or hit the end).",
    real: "Looking through every toy box in your room for your favorite teddy.",
    code: `function find(arr, x) {\n  for (let i = 0; i < arr.length; i++) {\n    if (arr[i] === x) return i;\n  }\n  return -1;\n}`,
    bigO: [{op:"Best", cx:"O(1)"}, {op:"Worst", cx:"O(n)"}],
    quiz: { q:"Linear search works on...", opts:["Only sorted lists","Any list","Only numbers"], answer:1, why:"Linear search doesn't care about order." },
  },
  "binary-search": {
    why: "Insanely fast on sorted data. 1 million items → only ~20 checks!",
    how: "Check the middle. If too big, search the left half. If too small, search the right half.",
    real: "Guessing a number 1–100: always start at 50.",
    code: `function binarySearch(a, x) {\n  let lo = 0, hi = a.length - 1;\n  while (lo <= hi) {\n    const mid = (lo + hi) >> 1;\n    if (a[mid] === x) return mid;\n    if (a[mid] < x) lo = mid + 1;\n    else hi = mid - 1;\n  }\n  return -1;\n}`,
    bigO: [{op:"Search", cx:"O(log n)"}],
    quiz: { q:"Binary search needs the array to be...", opts:["Big","Sorted","Numbers only"], answer:1, why:"You can't halve correctly without order." },
  },
  "bubble-sort": {
    why: "Simplest sort to understand. Not the fastest, but beautiful to watch.",
    how: "Compare adjacent pairs. Swap if out of order. Repeat until no swaps happen.",
    real: "Heaviest bubbles sink, lightest float to the top.",
    code: `function bubbleSort(a) {\n  for (let i = 0; i < a.length; i++)\n    for (let j = 0; j < a.length - i - 1; j++)\n      if (a[j] > a[j+1])\n        [a[j], a[j+1]] = [a[j+1], a[j]];\n  return a;\n}`,
    bigO: [{op:"Average", cx:"O(n²)"}, {op:"Best", cx:"O(n)"}],
    quiz: { q:"Bubble sort time complexity?", opts:["O(n)","O(n²)","O(log n)"], answer:1, why:"Two nested loops → quadratic." },
  },
  "selection-sort": {
    why: "Easy to remember: always pick the smallest leftover.",
    how: "Find the smallest item and swap it into position. Repeat for the rest.",
    real: "Lining up toys from smallest to biggest, one pick at a time.",
    code: `function selectionSort(a) {\n  for (let i = 0; i < a.length; i++) {\n    let m = i;\n    for (let j = i+1; j < a.length; j++) if (a[j] < a[m]) m = j;\n    [a[i], a[m]] = [a[m], a[i]];\n  }\n  return a;\n}`,
    bigO: [{op:"All cases", cx:"O(n²)"}],
    quiz: { q:"Selection sort picks the...", opts:["Random item","Smallest leftover","Last item"], answer:1, why:"Always the smallest remaining!" },
  },
  "insertion-sort": {
    why: "Fast on small or nearly-sorted lists. How most people sort cards by hand!",
    how: "Take each item and slide it backward into its right spot.",
    real: "Sorting playing cards in your hand.",
    code: `function insertionSort(a) {\n  for (let i = 1; i < a.length; i++) {\n    let j = i;\n    while (j > 0 && a[j-1] > a[j]) {\n      [a[j], a[j-1]] = [a[j-1], a[j]]; j--;\n    }\n  }\n  return a;\n}`,
    bigO: [{op:"Average", cx:"O(n²)"}, {op:"Best", cx:"O(n)"}],
    quiz: { q:"Insertion sort is great when...", opts:["Data is huge","Data is nearly sorted","Data is random"], answer:1, why:"Nearly sorted = almost no work!" },
  },
  "merge-sort": {
    why: "Reliably fast: always O(n log n). Stable sort, great for big lists.",
    how: "Split in half recursively, then merge sorted halves together.",
    real: "Two friends each sort half the toys, then zip them together.",
    code: `function mergeSort(a) {\n  if (a.length <= 1) return a;\n  const m = a.length >> 1;\n  return merge(mergeSort(a.slice(0,m)), mergeSort(a.slice(m)));\n}\nfunction merge(l, r) {\n  const out = [];\n  while (l.length && r.length) out.push(l[0] < r[0] ? l.shift() : r.shift());\n  return [...out, ...l, ...r];\n}`,
    bigO: [{op:"All cases", cx:"O(n log n)"}],
    quiz: { q:"Merge sort complexity?", opts:["O(n²)","O(n log n)","O(1)"], answer:1, why:"Split log n times, merge n each level." },
  },
  "quick-sort": {
    why: "Usually the fastest in practice. Used in many real-world libraries.",
    how: "Pick a pivot. Smaller items go left, bigger go right. Recurse on each side.",
    real: "Pick a 'leader' toy. Shorter toys stand left, taller stand right. Repeat per group.",
    code: `function quickSort(a) {\n  if (a.length <= 1) return a;\n  const p = a[0], l = [], r = [];\n  for (let i = 1; i < a.length; i++)\n    (a[i] < p ? l : r).push(a[i]);\n  return [...quickSort(l), p, ...quickSort(r)];\n}`,
    bigO: [{op:"Average", cx:"O(n log n)"}, {op:"Worst", cx:"O(n²)"}],
    quiz: { q:"Quicksort's key idea is the...", opts:["Pivot","Merge","Bubble"], answer:0, why:"Split around a pivot!" },
  },
  "bfs": {
    why: "Finds the shortest path in unweighted graphs. Great for level-by-level exploring.",
    how: "Use a queue. Visit all neighbors before going deeper.",
    real: "Inviting your closest friends first, then their friends, then their friends.",
    code: `function bfs(graph, start) {\n  const seen = new Set([start]);\n  const q = [start];\n  while (q.length) {\n    const n = q.shift();\n    for (const x of graph[n]) if (!seen.has(x)) { seen.add(x); q.push(x); }\n  }\n  return [...seen];\n}`,
    bigO: [{op:"Time", cx:"O(V + E)"}],
    quiz: { q:"BFS uses a...", opts:["Stack","Queue","Heap"], answer:1, why:"Queue gives level-by-level order." },
  },
  "dfs": {
    why: "Great for exploring all paths, solving mazes, detecting cycles.",
    how: "Use a stack (or recursion). Dive deep before backtracking.",
    real: "Pick one tunnel and follow it till the end, then back up.",
    code: `function dfs(graph, n, seen = new Set()) {\n  seen.add(n);\n  for (const x of graph[n]) if (!seen.has(x)) dfs(graph, x, seen);\n  return seen;\n}`,
    bigO: [{op:"Time", cx:"O(V + E)"}],
    quiz: { q:"DFS uses a...", opts:["Stack/recursion","Queue","Hash table"], answer:0, why:"Stack/recursion lets you dive deep." },
  },
};