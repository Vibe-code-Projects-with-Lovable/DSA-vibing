import { createFileRoute, notFound } from "@tanstack/react-router";
import { dataStructures } from "@/data/topics";
import { TopicDetail } from "@/components/TopicDetail";
import { ArrayDemo } from "@/components/demos/ArrayDemo";
import { StackDemo } from "@/components/demos/StackDemo";
import { QueueDemo } from "@/components/demos/QueueDemo";
import { LinkedListDemo } from "@/components/demos/LinkedListDemo";
import { HashTableDemo } from "@/components/demos/HashTableDemo";
import { TreeDemo } from "@/components/demos/TreeDemo";
import { GraphDemo } from "@/components/demos/GraphDemo";
import { HeapDemo } from "@/components/demos/HeapDemo";

const demos: Record<string, React.ReactNode> = {
  "array": <ArrayDemo />,
  "stack": <StackDemo />,
  "queue": <QueueDemo />,
  "linked-list": <LinkedListDemo />,
  "hash-table": <HashTableDemo />,
  "tree": <TreeDemo />,
  "graph": <GraphDemo />,
  "heap": <HeapDemo />,
};

export const Route = createFileRoute("/data-structures/$slug")({
  loader: ({ params }) => {
    const t = dataStructures.find((d) => d.slug === params.slug);
    if (!t) throw notFound();
    return { topic: t };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.topic.name ?? "Topic"} — DSA Playground` },
      { name: "description", content: loaderData?.topic.story ?? "" },
    ],
  }),
  notFoundComponent: () => <div className="p-10 text-center">Topic not found.</div>,
  errorComponent: ({ error }) => <div className="p-10 text-center">Oops: {error.message}</div>,
  component: DSPage,
});

function DSPage() {
  const { topic } = Route.useLoaderData();
  return <TopicDetail topic={topic} backTo="/data-structures" demo={demos[topic.slug] ?? <p>Demo coming soon!</p>} />;
}