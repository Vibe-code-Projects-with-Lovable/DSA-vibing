import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, PageShell } from "@/components/PageHeader";
import { TopicGrid } from "@/components/TopicGrid";
import { dataStructures } from "@/data/topics";

export const Route = createFileRoute("/data-structures/")({
  head: () => ({
    meta: [
      { title: "Data Structures — DSA Playground" },
      { name: "description", content: "Arrays, lists, stacks, queues, trees, graphs — explained with toys, treasure hunts and family trees." },
    ],
  }),
  component: DataStructuresHub,
});

function DataStructuresHub() {
  return (
    <PageShell>
      <PageHeader
        emoji="📦"
        title="Data Structures"
        subtitle="Different ways to store your toys, treasures, and secrets."
      />
      <TopicGrid basePath="/data-structures" topics={dataStructures} />
    </PageShell>
  );
}