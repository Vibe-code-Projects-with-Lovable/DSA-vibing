import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, PageShell, Section } from "@/components/PageHeader";
import { ArrayDemo } from "@/components/demos/ArrayDemo";
import { StackDemo } from "@/components/demos/StackDemo";
import { QueueDemo } from "@/components/demos/QueueDemo";
import { LinkedListDemo } from "@/components/demos/LinkedListDemo";
import { HashTableDemo } from "@/components/demos/HashTableDemo";
import { TreeDemo } from "@/components/demos/TreeDemo";
import { GraphDemo } from "@/components/demos/GraphDemo";
import { HeapDemo } from "@/components/demos/HeapDemo";

export const Route = createFileRoute("/playground")({
  head: () => ({
    meta: [
      { title: "Playground — DSA Playground" },
      { name: "description", content: "Build, break, and explore data structures hands-on." },
    ],
  }),
  component: Playground,
});

const toys = [
  { id: "array", label: "📦 Array", el: <ArrayDemo /> },
  { id: "stack", label: "🥞 Stack", el: <StackDemo /> },
  { id: "queue", label: "🍦 Queue", el: <QueueDemo /> },
  { id: "list", label: "🔗 Linked List", el: <LinkedListDemo /> },
  { id: "hash", label: "📬 Hash Table", el: <HashTableDemo /> },
  { id: "tree", label: "🌳 Tree", el: <TreeDemo /> },
  { id: "graph", label: "🗺️ Graph", el: <GraphDemo /> },
  { id: "heap", label: "👑 Heap", el: <HeapDemo /> },
] as const;

function Playground() {
  const [t, setT] = useState<typeof toys[number]["id"]>("array");
  return (
    <PageShell>
      <PageHeader emoji="🎮" title="Playground" subtitle="Your sandbox. Click. Add. Break. Learn." />
      <div className="flex flex-wrap gap-2 mb-6 justify-center">
        {toys.map((x) => (
          <button key={x.id} onClick={() => setT(x.id)} className={`px-4 py-2 rounded-xl font-bold text-sm transition-all ${
            t === x.id ? "bg-gradient-primary text-white shadow-soft" : "glass hover:scale-105"
          }`}>
            {x.label}
          </button>
        ))}
      </div>
      <Section title="">{toys.find((x) => x.id === t)!.el}</Section>
    </PageShell>
  );
}