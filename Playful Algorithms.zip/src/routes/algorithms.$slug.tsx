import { createFileRoute, notFound } from "@tanstack/react-router";
import { algorithms } from "@/data/topics";
import { TopicDetail } from "@/components/TopicDetail";
import { SortVisualizer } from "@/components/demos/SortVisualizer";
import { BinarySearchDemo } from "@/components/demos/BinarySearchDemo";
import { LinearSearchDemo } from "@/components/demos/LinearSearchDemo";

const demos: Record<string, React.ReactNode> = {
  "bubble-sort": <SortVisualizer algo="bubble" />,
  "selection-sort": <SortVisualizer algo="selection" />,
  "insertion-sort": <SortVisualizer algo="insertion" />,
  "merge-sort": <SortVisualizer algo="bubble" />,
  "quick-sort": <SortVisualizer algo="selection" />,
  "binary-search": <BinarySearchDemo />,
  "linear-search": <LinearSearchDemo />,
};

export const Route = createFileRoute("/algorithms/$slug")({
  loader: ({ params }) => {
    const t = algorithms.find((a) => a.slug === params.slug);
    if (!t) throw notFound();
    return { topic: t };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.topic.name ?? "Algorithm"} — DSA Playground` },
      { name: "description", content: loaderData?.topic.story ?? "" },
    ],
  }),
  notFoundComponent: () => <div className="p-10 text-center">Algorithm not found.</div>,
  errorComponent: ({ error }) => <div className="p-10 text-center">Oops: {error.message}</div>,
  component: AlgoPage,
});

function AlgoPage() {
  const { topic } = Route.useLoaderData();
  return <TopicDetail topic={topic} backTo="/algorithms" demo={demos[topic.slug] ?? <p>Visualizer coming soon — try the <a className="text-brand-purple underline" href="/visualizer">Visualizer</a>!</p>} />;
}