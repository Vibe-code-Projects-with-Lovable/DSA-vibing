import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion, Reorder } from "framer-motion";
const fire = async () => {
  if (typeof window === "undefined") return;
  const { default: confetti } = await import("canvas-confetti");
  confetti({ particleCount: 150, spread: 100, origin: { y: 0.6 } });
};
import { Trophy, Star } from "lucide-react";
import { PageHeader, PageShell, Section } from "@/components/PageHeader";

export const Route = createFileRoute("/challenges")({
  head: () => ({
    meta: [
      { title: "Challenges — DSA Playground" },
      { name: "description", content: "Mini games that turn DSA into pure fun." },
    ],
  }),
  component: Challenges,
});

function SortTheToys() {
  const target = [1, 2, 3, 4, 5];
  const [items, setItems] = useState([4, 1, 5, 2, 3]);
  const [won, setWon] = useState(false);

  const check = () => {
    if (items.every((v, i) => v === target[i])) {
      setWon(true);
      fire();
    }
  };

  return (
    <div>
      <p className="text-sm text-muted-foreground mb-3">Drag the toys into order from smallest to biggest, then click Check!</p>
      <Reorder.Group axis="x" values={items} onReorder={setItems} className="flex gap-2 flex-wrap mb-4">
        {items.map((v) => (
          <Reorder.Item key={v} value={v} className="cursor-grab active:cursor-grabbing">
            <div className="h-16 w-16 rounded-2xl bg-gradient-primary text-white grid place-items-center font-bold text-xl shadow-soft">{v}</div>
          </Reorder.Item>
        ))}
      </Reorder.Group>
      <button onClick={check} className="bg-gradient-warm text-foreground font-bold px-4 py-2 rounded-xl">Check ✓</button>
      {won && <motion.div initial={{scale:0}} animate={{scale:1}} className="mt-3 text-brand-green font-bold">🎉 Sorted! +50 XP</motion.div>}
    </div>
  );
}

function BuildTheQueue() {
  const correct = ["Alice","Bob","Charlie","Diana"];
  const [items, setItems] = useState(["Diana","Alice","Charlie","Bob"]);
  const [won, setWon] = useState(false);
  const check = () => {
    if (items.every((v,i)=>v===correct[i])) { setWon(true); fire(); }
  };
  return (
    <div>
      <p className="text-sm text-muted-foreground mb-3">Alice arrived first, then Bob, then Charlie, then Diana. Order the queue!</p>
      <Reorder.Group axis="x" values={items} onReorder={setItems} className="flex gap-2 flex-wrap mb-4">
        {items.map((v) => (
          <Reorder.Item key={v} value={v} className="cursor-grab active:cursor-grabbing">
            <div className="px-4 h-12 rounded-xl glass-strong grid place-items-center font-bold">{v}</div>
          </Reorder.Item>
        ))}
      </Reorder.Group>
      <button onClick={check} className="bg-gradient-warm text-foreground font-bold px-4 py-2 rounded-xl">Check ✓</button>
      {won && <motion.div initial={{scale:0}} animate={{scale:1}} className="mt-3 text-brand-green font-bold">🎉 Perfect queue! +75 XP</motion.div>}
    </div>
  );
}

function Challenges() {
  return (
    <PageShell>
      <PageHeader emoji="🏆" title="Challenges" subtitle="Mini games. Big XP. Bragging rights." />
      <div className="grid sm:grid-cols-3 gap-3 mb-8">
        {[
          { icon: Star, label: "Stars", val: 12, c: "from-brand-yellow to-brand-pink" },
          { icon: Trophy, label: "Badges", val: 3, c: "from-brand-purple to-brand-blue" },
          { icon: Star, label: "XP", val: 420, c: "from-brand-green to-brand-blue" },
        ].map((s) => (
          <div key={s.label} className={`rounded-2xl p-4 bg-gradient-to-br ${s.c} text-white shadow-soft`}>
            <s.icon className="h-5 w-5 mb-1" />
            <div className="text-3xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>{s.val}</div>
            <div className="text-sm opacity-90">{s.label}</div>
          </div>
        ))}
      </div>
      <Section title="🧸 Sort the Toys"><SortTheToys /></Section>
      <Section title="🍦 Build the Queue"><BuildTheQueue /></Section>
    </PageShell>
  );
}