import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, PageShell, Section } from "@/components/PageHeader";
import { QuizCard } from "@/components/QuizCard";
import { content } from "@/data/topicContent";
import { dataStructures, algorithms } from "@/data/topics";

export const Route = createFileRoute("/quizzes")({
  head: () => ({
    meta: [
      { title: "Quizzes — DSA Playground" },
      { name: "description", content: "Test what you've learned." },
    ],
  }),
  component: Quizzes,
});

function Quizzes() {
  const all = [...dataStructures, ...algorithms].filter((t) => content[t.slug]);
  return (
    <PageShell>
      <PageHeader emoji="🧠" title="Quizzes" subtitle="One quick question per topic. No pressure!" />
      <div className="space-y-5">
        {all.map((t) => (
          <Section key={t.slug} title={`${t.emoji} ${t.name}`}>
            <QuizCard quiz={content[t.slug].quiz} />
          </Section>
        ))}
      </div>
    </PageShell>
  );
}