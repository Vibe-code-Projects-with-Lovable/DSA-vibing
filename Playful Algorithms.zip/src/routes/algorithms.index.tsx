import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, PageShell } from "@/components/PageHeader";
import { TopicGrid } from "@/components/TopicGrid";
import { algorithms } from "@/data/topics";

export const Route = createFileRoute("/algorithms/")({
  head: () => ({
    meta: [
      { title: "Algorithms — DSA Playground" },
      { name: "description", content: "Sort, search, and explore — every algorithm as a story and animation." },
    ],
  }),
  component: AlgorithmsHub,
});

function AlgorithmsHub() {
  return (
    <PageShell>
      <PageHeader
        emoji="🍪"
        title="Algorithms"
        subtitle="Recipes that tell the computer how to do things step by step."
      />
      <TopicGrid basePath="/algorithms" topics={algorithms} />
    </PageShell>
  );
}