import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Award, Flame, Clock, BookOpen } from "lucide-react";
import { PageHeader, PageShell, Section } from "@/components/PageHeader";

export const Route = createFileRoute("/progress")({
  head: () => ({
    meta: [
      { title: "Progress — DSA Playground" },
      { name: "description", content: "Track your learning streak, XP, and badges." },
    ],
  }),
  component: ProgressPage,
});

const stats = [
  { icon: BookOpen, label: "Lessons", val: "8 / 17", pct: 47, c: "from-brand-blue to-brand-purple" },
  { icon: Flame, label: "Streak", val: "5 days", pct: 70, c: "from-brand-yellow to-brand-pink" },
  { icon: Clock, label: "Time", val: "2h 14m", pct: 30, c: "from-brand-green to-brand-blue" },
  { icon: Award, label: "Badges", val: "3", pct: 25, c: "from-brand-purple to-brand-pink" },
];
const badges = [
  { e: "🥇", n: "First Steps" },
  { e: "🫧", n: "Sort Master" },
  { e: "🌳", n: "Tree Hugger" },
  { e: "🔒", n: "??? Locked" },
  { e: "🔒", n: "??? Locked" },
];

function ProgressPage() {
  return (
    <PageShell>
      <PageHeader emoji="⭐" title="Your Progress" subtitle="Look how far you've come!" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((s, i) => (
          <motion.div key={s.label} initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{delay:i*0.05}}
            className="glass-strong rounded-3xl p-5">
            <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${s.c} grid place-items-center mb-3`}>
              <s.icon className="h-5 w-5 text-white" />
            </div>
            <div className="text-2xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>{s.val}</div>
            <div className="text-xs text-muted-foreground mb-2">{s.label}</div>
            <div className="h-2 rounded-full bg-muted overflow-hidden">
              <motion.div initial={{width:0}} animate={{width:`${s.pct}%`}} transition={{duration:1, delay:0.2}}
                className={`h-full bg-gradient-to-r ${s.c}`} />
            </div>
          </motion.div>
        ))}
      </div>
      <Section title="🏅 Badges">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {badges.map((b,i) => (
            <div key={i} className="glass rounded-2xl p-4 text-center">
              <div className="text-4xl mb-1">{b.e}</div>
              <div className="text-xs font-bold">{b.n}</div>
            </div>
          ))}
        </div>
      </Section>
    </PageShell>
  );
}