import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Gamepad2, Trophy, Brain, Eye, Boxes, Workflow } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DSA Playground for Kids — Learn DSA Like You're 5" },
      { name: "description", content: "Turn scary coding concepts into fun stories, animations, and games." },
    ],
  }),
  component: Landing,
});

const floatingToys = [
  { emoji: "📦", x: "8%", y: "20%", delay: 0 },
  { emoji: "🧸", x: "85%", y: "15%", delay: 0.5 },
  { emoji: "⚽", x: "12%", y: "75%", delay: 1 },
  { emoji: "🚂", x: "82%", y: "70%", delay: 1.5 },
  { emoji: "🌳", x: "50%", y: "10%", delay: 2 },
  { emoji: "🎈", x: "92%", y: "45%", delay: 2.5 },
  { emoji: "🧩", x: "5%", y: "50%", delay: 3 },
];

const features = [
  { icon: Boxes, title: "Data Structures", desc: "Toy boxes, treasure hunts, family trees", to: "/data-structures", grad: "from-brand-blue to-brand-purple" },
  { icon: Workflow, title: "Algorithms", desc: "Step-by-step recipes & adventures", to: "/algorithms", grad: "from-brand-purple to-brand-pink" },
  { icon: Eye, title: "Visualizer", desc: "Watch sorting & searching in action", to: "/visualizer", grad: "from-brand-pink to-brand-yellow" },
  { icon: Gamepad2, title: "Playground", desc: "Build & break your own structures", to: "/playground", grad: "from-brand-green to-brand-blue" },
  { icon: Trophy, title: "Challenges", desc: "Mini games to earn stars & badges", to: "/challenges", grad: "from-brand-yellow to-brand-pink" },
  { icon: Brain, title: "Quizzes", desc: "Test what you learned, get rewarded", to: "/quizzes", grad: "from-brand-purple to-brand-green" },
];

function Landing() {
  return (
    <div>
      {/* HERO */}
      <section className="relative px-4 lg:px-8 pt-12 pb-24 lg:pt-20 lg:pb-32 overflow-hidden">
        {floatingToys.map((t, i) => (
          <motion.div
            key={i}
            className="hidden md:block absolute text-5xl select-none pointer-events-none"
            style={{ left: t.x, top: t.y }}
            animate={{ y: [0, -25, 0], rotate: [0, 10, -5, 0] }}
            transition={{ duration: 6, repeat: Infinity, delay: t.delay, ease: "easeInOut" }}
          >
            {t.emoji}
          </motion.div>
        ))}

        <div className="max-w-5xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-sm font-semibold mb-6"
          >
            <Sparkles className="h-4 w-4 text-brand-purple" />
            Built for kids, beginners, and curious humans
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.05] tracking-tight"
            style={{ fontFamily: "Fredoka, sans-serif" }}
          >
            Learn <span className="text-gradient-primary">Data Structures</span>
            <br />& Algorithms like
            <br />you're <span className="text-gradient-primary">5 years old</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="mt-8 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Turn scary coding concepts into fun stories, animations, and games.
            No PhD required — just curiosity. 🚀
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
            className="mt-10 flex flex-wrap items-center justify-center gap-3"
          >
            <Link
              to="/data-structures"
              className="group inline-flex items-center gap-2 bg-gradient-primary text-white font-bold px-7 py-3.5 rounded-2xl shadow-glow hover:scale-105 transition-transform"
            >
              Start Learning
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              to="/playground"
              className="inline-flex items-center gap-2 glass-strong font-bold px-7 py-3.5 rounded-2xl hover:scale-105 transition-transform"
            >
              <Gamepad2 className="h-4 w-4" />
              Explore Playground
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-16 flex flex-wrap justify-center gap-8 text-sm text-muted-foreground"
          >
            {[
              { n: "20+", l: "Concepts" },
              { n: "100%", l: "Interactive" },
              { n: "0", l: "Boring lectures" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-3xl font-bold text-gradient-primary" style={{ fontFamily: "Fredoka, sans-serif" }}>{s.n}</div>
                <div>{s.l}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="px-4 lg:px-8 pb-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-5xl font-bold text-center mb-3" style={{ fontFamily: "Fredoka, sans-serif" }}>
            Pick your <span className="text-gradient-primary">adventure</span>
          </h2>
          <p className="text-center text-muted-foreground mb-12">Every topic feels like a game — promise.</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <motion.div
                  key={f.to}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Link
                    to={f.to}
                    className="block group glass-strong rounded-3xl p-6 hover:shadow-glow hover:-translate-y-1 transition-all"
                  >
                    <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${f.grad} grid place-items-center shadow-soft mb-4 group-hover:scale-110 group-hover:rotate-6 transition-transform`}>
                      <Icon className="h-7 w-7 text-white" />
                    </div>
                    <div className="text-xl font-bold mb-1" style={{ fontFamily: "Fredoka, sans-serif" }}>{f.title}</div>
                    <div className="text-sm text-muted-foreground">{f.desc}</div>
                    <div className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-purple">
                      Open <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
