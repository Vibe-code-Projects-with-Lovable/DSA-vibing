import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, PageShell, Section } from "@/components/PageHeader";
import { SortVisualizer } from "@/components/demos/SortVisualizer";
import { BinarySearchDemo } from "@/components/demos/BinarySearchDemo";
import { LinearSearchDemo } from "@/components/demos/LinearSearchDemo";

export const Route = createFileRoute("/visualizer")({
  head: () => ({
    meta: [
      { title: "Visualizer — DSA Playground" },
      { name: "description", content: "Watch sorting and searching algorithms come to life." },
    ],
  }),
  component: Visualizer,
});

const tabs = [
  { id: "bubble", label: "🫧 Bubble Sort", el: <SortVisualizer algo="bubble" /> },
  { id: "selection", label: "🎯 Selection Sort", el: <SortVisualizer algo="selection" /> },
  { id: "insertion", label: "🃏 Insertion Sort", el: <SortVisualizer algo="insertion" /> },
  { id: "binary", label: "🎯 Binary Search", el: <BinarySearchDemo /> },
  { id: "linear", label: "🔍 Linear Search", el: <LinearSearchDemo /> },
] as const;

function Visualizer() {
  const [tab, setTab] = useState<typeof tabs[number]["id"]>("bubble");
  return (
    <PageShell>
      <PageHeader emoji="🎬" title="Visualizer" subtitle="Pick an algorithm and watch the magic happen." />
      <div className="flex flex-wrap gap-2 mb-6 justify-center">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 rounded-xl font-bold text-sm transition-all ${
              tab === t.id ? "bg-gradient-primary text-white shadow-soft" : "glass hover:scale-105"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <Section title="">{tabs.find((t) => t.id === tab)!.el}</Section>
    </PageShell>
  );
}