import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";
import type { Topic } from "@/data/topics";
import { content } from "@/data/topicContent";
import { PageShell, Section } from "@/components/PageHeader";
import { CodeBlock } from "@/components/CodeBlock";
import { QuizCard } from "@/components/QuizCard";

export function TopicDetail({
  topic,
  backTo,
  demo,
}: {
  topic: Topic;
  backTo: string;
  demo: React.ReactNode;
}) {
  const c = content[topic.slug];
  if (!c) return <PageShell><p>Content coming soon for {topic.name}.</p></PageShell>;

  return (
    <PageShell>
      <Link to={backTo} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" /> Back
      </Link>

      <motion.div initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} className="text-center mb-10">
        <div className={`inline-grid place-items-center h-20 w-20 rounded-3xl bg-gradient-to-br ${topic.grad} shadow-glow text-5xl mb-4`}>
          {topic.emoji}
        </div>
        <h1 className="text-4xl md:text-6xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>
          <span className="text-gradient-primary">{topic.name}</span>
        </h1>
        <p className="mt-2 text-muted-foreground">{topic.blurb}</p>
      </motion.div>

      <Section title="📖 The story">
        <p className="text-lg leading-relaxed">{topic.story}</p>
      </Section>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <div className="glass-strong rounded-3xl p-6">
          <h3 className="font-bold mb-2" style={{ fontFamily: "Fredoka, sans-serif" }}>🤔 Why do we need it?</h3>
          <p className="text-sm">{c.why}</p>
        </div>
        <div className="glass-strong rounded-3xl p-6">
          <h3 className="font-bold mb-2" style={{ fontFamily: "Fredoka, sans-serif" }}>⚙️ How does it work?</h3>
          <p className="text-sm">{c.how}</p>
        </div>
        <div className="glass-strong rounded-3xl p-6 md:col-span-2">
          <h3 className="font-bold mb-2" style={{ fontFamily: "Fredoka, sans-serif" }}>🌍 Real-life example</h3>
          <p className="text-sm">{c.real}</p>
        </div>
      </div>

      <Section title="🎮 Try it yourself">{demo}</Section>

      <Section title="💻 Code example">
        <CodeBlock code={c.code} />
      </Section>

      {c.bigO && (
        <Section title="⏱️ How fast is it?">
          <div className="grid sm:grid-cols-3 gap-3">
            {c.bigO.map((b) => (
              <div key={b.op} className="glass rounded-2xl p-4 text-center">
                <div className="text-xs text-muted-foreground">{b.op}</div>
                <div className="text-2xl font-bold text-gradient-primary" style={{ fontFamily: "Fredoka, sans-serif" }}>{b.cx}</div>
              </div>
            ))}
          </div>
        </Section>
      )}

      <Section title="🧠 Quick quiz">
        <QuizCard quiz={c.quiz} />
      </Section>
    </PageShell>
  );
}