import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, X } from "lucide-react";
import type { Quiz } from "@/data/topicContent";

export function QuizCard({ quiz }: { quiz: Quiz }) {
  const [pick, setPick] = useState<number | null>(null);

  const choose = async (i: number) => {
    setPick(i);
    if (i === quiz.answer && typeof window !== "undefined") {
      const { default: confetti } = await import("canvas-confetti");
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.7 } });
    }
  };

  return (
    <div>
      <div className="text-lg font-bold mb-4" style={{ fontFamily: "Fredoka, sans-serif" }}>{quiz.q}</div>
      <div className="grid sm:grid-cols-3 gap-3">
        {quiz.opts.map((o, i) => {
          const correct = i === quiz.answer;
          const chosen = pick === i;
          return (
            <button
              key={i}
              onClick={() => choose(i)}
              disabled={pick !== null}
              className={`relative text-left px-4 py-3 rounded-2xl font-semibold border-2 transition-all ${
                pick === null
                  ? "border-border hover:border-brand-purple hover:scale-[1.02] glass"
                  : correct
                  ? "border-brand-green bg-brand-green/15"
                  : chosen
                  ? "border-destructive bg-destructive/10"
                  : "border-border opacity-50 glass"
              }`}
            >
              {o}
              {pick !== null && correct && <Check className="inline ml-2 h-4 w-4 text-brand-green" />}
              {pick !== null && chosen && !correct && <X className="inline ml-2 h-4 w-4 text-destructive" />}
            </button>
          );
        })}
      </div>
      <AnimatePresence>
        {pick !== null && (
          <motion.div initial={{opacity:0,y:5}} animate={{opacity:1,y:0}}
            className="mt-4 p-4 rounded-2xl glass text-sm font-medium">
            💡 {quiz.why}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}