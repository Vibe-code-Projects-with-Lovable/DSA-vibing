export function CodeBlock({ code }: { code: string }) {
  return (
    <pre className="rounded-2xl bg-foreground/90 text-background p-4 overflow-x-auto text-sm font-mono leading-relaxed">
      <code>{code}</code>
    </pre>
  );
}