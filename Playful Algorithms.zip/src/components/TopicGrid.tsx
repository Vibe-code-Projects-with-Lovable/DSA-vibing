import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import type { Topic } from "@/data/topics";

export function TopicGrid({ basePath, topics }: { basePath: string; topics: Topic[] }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {topics.map((t, i) => (
        <motion.div
          key={t.slug}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.04 }}
        >
          <Link
            to={`${basePath}/$slug`}
            params={{ slug: t.slug }}
            className="block group glass-strong rounded-3xl p-6 hover:shadow-glow hover:-translate-y-1 transition-all h-full"
          >
            <div className={`h-16 w-16 rounded-2xl bg-gradient-to-br ${t.grad} grid place-items-center shadow-soft mb-4 group-hover:scale-110 group-hover:rotate-6 transition-transform text-3xl`}>
              <span>{t.emoji}</span>
            </div>
            <div className="text-xl font-bold mb-1" style={{ fontFamily: "Fredoka, sans-serif" }}>{t.name}</div>
            <div className="text-sm text-muted-foreground">{t.blurb}</div>
          </Link>
        </motion.div>
      ))}
    </div>
  );
}