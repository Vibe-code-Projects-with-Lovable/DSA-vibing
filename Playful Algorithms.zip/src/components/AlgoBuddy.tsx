import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X } from "lucide-react";
import { useRouterState } from "@tanstack/react-router";

const tips: Record<string, string[]> = {
  "/": ["Hi! I'm Algo Buddy 👋", "Pick a topic and let's play!", "Try the Playground first!"],
  "/data-structures": ["Data structures are like toy boxes 📦", "Each one stores things differently!"],
  "/algorithms": ["Algorithms are recipes 🍪", "They tell the computer what to do step-by-step."],
  "/visualizer": ["Watch the magic happen! ✨", "Try changing the speed!"],
  "/playground": ["Build your own structures! 🧱"],
  "/challenges": ["You got this, champion! 🏆"],
  "/quizzes": ["Brain workout time! 🧠"],
  "/progress": ["Look how far you've come! ⭐"],
};

export function AlgoBuddy() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(true);
  const [idx, setIdx] = useState(0);

  const messages = tips[path] || tips["/"];

  useEffect(() => {
    setIdx(0);
    setOpen(true);
  }, [path]);

  useEffect(() => {
    if (!open) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % messages.length), 4000);
    return () => clearInterval(t);
  }, [open, messages.length]);

  return (
    <div className="fixed bottom-5 right-5 z-50 flex items-end gap-2">
      <AnimatePresence>
        {open && (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.9 }}
            className="glass-strong rounded-2xl rounded-br-sm px-4 py-2.5 max-w-[240px] shadow-glow text-sm font-medium"
          >
            {messages[idx]}
          </motion.div>
        )}
      </AnimatePresence>
      <motion.button
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(!open)}
        aria-label="Algo Buddy"
        className="relative h-16 w-16 rounded-full bg-gradient-primary shadow-glow grid place-items-center"
      >
        <motion.div
          animate={{ y: [0, -4, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="text-3xl"
        >
          🤖
        </motion.div>
        <span className="absolute -top-1 -right-1 h-6 w-6 rounded-full bg-brand-yellow grid place-items-center text-foreground">
          {open ? <X className="h-3 w-3" /> : <MessageCircle className="h-3 w-3" />}
        </span>
      </motion.button>
    </div>
  );
}