import { Link, useRouterState } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import {
  Home, Boxes, Workflow, Eye, Gamepad2, Trophy, Brain, BarChart3,
  Sparkles, Menu, X, Moon, Sun,
} from "lucide-react";
import { AlgoBuddy } from "./AlgoBuddy";

const nav = [
  { to: "/", label: "Home", icon: Home },
  { to: "/data-structures", label: "Data Structures", icon: Boxes },
  { to: "/algorithms", label: "Algorithms", icon: Workflow },
  { to: "/visualizer", label: "Visualizer", icon: Eye },
  { to: "/playground", label: "Playground", icon: Gamepad2 },
  { to: "/challenges", label: "Challenges", icon: Trophy },
  { to: "/quizzes", label: "Quizzes", icon: Brain },
  { to: "/progress", label: "Progress", icon: BarChart3 },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(false);

  const toggleDark = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
  };

  return (
    <div className="min-h-dvh bg-background text-foreground relative overflow-x-hidden">
      {/* Decorative blobs */}
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-brand-blue/30 blur-3xl animate-blob" />
        <div className="absolute top-1/3 -right-32 h-96 w-96 rounded-full bg-brand-pink/30 blur-3xl animate-blob" style={{ animationDelay: "3s" }} />
        <div className="absolute bottom-0 left-1/3 h-96 w-96 rounded-full bg-brand-green/20 blur-3xl animate-blob" style={{ animationDelay: "6s" }} />
      </div>

      {/* Top nav */}
      <header className="sticky top-0 z-40 glass border-b border-border/40">
        <div className="flex items-center justify-between px-4 lg:px-8 h-16">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="h-9 w-9 rounded-xl bg-gradient-primary grid place-items-center shadow-glow group-hover:scale-110 transition-transform">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div className="font-bold text-lg leading-none">
              <div className="text-gradient-primary" style={{ fontFamily: "Fredoka, sans-serif" }}>DSA Playground</div>
              <div className="text-[10px] text-muted-foreground font-medium">for curious minds</div>
            </div>
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {nav.slice(0, 6).map((item) => {
              const active = path === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`px-3 py-2 rounded-xl text-sm font-semibold transition-all ${
                    active ? "bg-gradient-primary text-white shadow-soft" : "hover:bg-muted text-foreground/80"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleDark}
              aria-label="Toggle dark mode"
              className="h-10 w-10 grid place-items-center rounded-xl glass hover:scale-105 transition-transform"
            >
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <button
              onClick={() => setOpen(!open)}
              aria-label="Toggle menu"
              className="lg:hidden h-10 w-10 grid place-items-center rounded-xl glass"
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden overflow-hidden border-t border-border/40"
            >
              <div className="px-4 py-3 grid grid-cols-2 gap-2">
                {nav.map((item) => {
                  const Icon = item.icon;
                  const active = path === item.to;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setOpen(false)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold ${
                        active ? "bg-gradient-primary text-white" : "bg-muted/50"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main>{children}</main>

      <footer className="mt-20 border-t border-border/40 px-4 lg:px-8 py-8 text-center text-sm text-muted-foreground">
        Made with <span className="text-brand-pink">♥</span> for curious minds. Learn. Play. Build.
      </footer>

      <AlgoBuddy />
    </div>
  );
}