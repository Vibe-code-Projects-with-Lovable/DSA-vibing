import { useState } from "react";
import { motion } from "framer-motion";

export function LinearSearchDemo() {
  const [arr] = useState([3, 8, 1, 9, 4, 6, 2, 7]);
  const [target, setTarget] = useState(6);
  const [cur, setCur] = useState(-1);
  const [found, setFound] = useState<number | null>(null);

  const run = async () => {
    setFound(null);
    for (let i = 0; i < arr.length; i++) {
      setCur(i);
      await new Promise(r => setTimeout(r, 500));
      if (arr[i] === target) { setFound(i); return; }
    }
    setCur(-1);
  };

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-5 items-center">
        <label className="text-sm font-semibold">Find:</label>
        <select value={target} onChange={(e)=>setTarget(+e.target.value)} className="rounded-xl px-3 py-2 bg-muted font-bold">
          {arr.map(v => <option key={v}>{v}</option>)}
        </select>
        <button onClick={run} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl">▶ Start search</button>
      </div>
      <div className="flex flex-wrap gap-2 justify-center">
        {arr.map((v, i) => (
          <motion.div key={i} animate={{scale: cur===i||found===i?1.15:1}}
            className={`h-14 w-14 rounded-2xl grid place-items-center font-bold text-white shadow-soft ${
              found === i ? "bg-brand-green ring-4 ring-brand-yellow" :
              cur === i ? "bg-brand-yellow text-foreground" : "bg-gradient-primary"
            }`}>
            {v}
          </motion.div>
        ))}
      </div>
      <p className="text-center mt-4 text-sm text-muted-foreground">
        {found !== null ? `Found at index ${found}! 🎉` : "Walks through every box, one at a time."}
      </p>
    </div>
  );
}