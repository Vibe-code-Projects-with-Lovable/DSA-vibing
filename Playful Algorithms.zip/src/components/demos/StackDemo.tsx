import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const colors = ["bg-brand-yellow", "bg-brand-pink", "bg-brand-purple", "bg-brand-blue", "bg-brand-green"];

export function StackDemo() {
  const [stack, setStack] = useState<number[]>([1, 2, 3]);
  const push = () => setStack([...stack, stack.length + 1]);
  const pop = () => setStack(stack.slice(0, -1));

  return (
    <div>
      <div className="flex gap-2 mb-5">
        <button onClick={push} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl hover:scale-105 transition-transform">+ Push pancake</button>
        <button onClick={pop} className="bg-muted font-bold px-4 py-2 rounded-xl hover:scale-105 transition-transform">– Pop</button>
        <span className="self-center text-sm text-muted-foreground">Peek: <b>{stack[stack.length - 1] ?? "—"}</b></span>
      </div>
      <div className="flex flex-col-reverse items-center min-h-[260px] justify-end gap-1 p-4 rounded-2xl bg-muted/40">
        <AnimatePresence>
          {stack.map((v, i) => (
            <motion.div
              key={v + "-" + i}
              initial={{ y: -50, opacity: 0, rotate: -10 }}
              animate={{ y: 0, opacity: 1, rotate: 0 }}
              exit={{ y: -50, opacity: 0 }}
              className={`h-12 w-56 rounded-full ${colors[i % colors.length]} shadow-soft grid place-items-center font-bold text-white`}
            >
              🥞 #{v}
            </motion.div>
          ))}
        </AnimatePresence>
        <div className="h-3 w-64 bg-foreground/20 rounded-full mt-2" />
      </div>
    </div>
  );
}