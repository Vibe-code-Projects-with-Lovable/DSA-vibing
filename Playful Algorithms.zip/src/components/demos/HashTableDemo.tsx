import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export function HashTableDemo() {
  const [entries, setEntries] = useState<{ k: string; v: string }[]>([
    { k: "John", v: "🎂 10" },
    { k: "Lisa", v: "🎂 7" },
  ]);
  const [k, setK] = useState(""); const [v, setV] = useState("");
  const add = () => { if (k && v) { setEntries([...entries.filter(e=>e.k!==k), { k, v }]); setK(""); setV(""); } };

  return (
    <div>
      <div className="flex gap-2 mb-5 flex-wrap">
        <input value={k} onChange={(e)=>setK(e.target.value)} placeholder="name" className="rounded-xl px-3 py-2 bg-muted border border-border w-28 font-semibold" />
        <input value={v} onChange={(e)=>setV(e.target.value)} placeholder="age" className="rounded-xl px-3 py-2 bg-muted border border-border w-28 font-semibold" />
        <button onClick={add} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl">+ Put in mailbox</button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <AnimatePresence>
          {entries.map((e) => (
            <motion.div key={e.k} layout initial={{scale:0}} animate={{scale:1}} exit={{scale:0}}
              className="glass rounded-2xl p-4 text-center">
              <div className="text-3xl mb-1">📬</div>
              <div className="font-bold text-gradient-primary">{e.k}</div>
              <div className="text-xs text-muted-foreground">→ {e.v}</div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}