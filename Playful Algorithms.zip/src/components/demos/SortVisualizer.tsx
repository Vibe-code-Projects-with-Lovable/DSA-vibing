import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Play, Pause, RotateCcw, Shuffle } from "lucide-react";

type Algo = "bubble" | "selection" | "insertion";

type Step = { arr: number[]; a?: number; b?: number; sorted: number[] };

function bubbleSteps(arr: number[]): Step[] {
  const steps: Step[] = []; const a = [...arr]; const sorted: number[] = [];
  for (let i = 0; i < a.length; i++) {
    for (let j = 0; j < a.length - i - 1; j++) {
      steps.push({ arr: [...a], a: j, b: j+1, sorted: [...sorted] });
      if (a[j] > a[j+1]) { [a[j], a[j+1]] = [a[j+1], a[j]]; steps.push({ arr: [...a], a: j, b: j+1, sorted: [...sorted] }); }
    }
    sorted.unshift(a.length - i - 1);
  }
  steps.push({ arr: [...a], sorted: a.map((_,k)=>k) }); return steps;
}
function selectionSteps(arr: number[]): Step[] {
  const steps: Step[] = []; const a = [...arr]; const sorted: number[] = [];
  for (let i = 0; i < a.length; i++) {
    let min = i;
    for (let j = i+1; j < a.length; j++) { steps.push({arr:[...a],a:min,b:j,sorted:[...sorted]}); if (a[j]<a[min]) min=j; }
    [a[i],a[min]] = [a[min],a[i]]; sorted.push(i); steps.push({arr:[...a],sorted:[...sorted]});
  } return steps;
}
function insertionSteps(arr: number[]): Step[] {
  const steps: Step[] = []; const a = [...arr];
  for (let i=1;i<a.length;i++){ let j=i;
    while(j>0 && a[j-1]>a[j]){ steps.push({arr:[...a],a:j,b:j-1,sorted:[]}); [a[j],a[j-1]]=[a[j-1],a[j]]; j--; }
  } steps.push({arr:[...a], sorted:a.map((_,k)=>k)}); return steps;
}

const builders: Record<Algo, (a: number[]) => Step[]> = {
  bubble: bubbleSteps, selection: selectionSteps, insertion: insertionSteps,
};

export function SortVisualizer({ algo = "bubble" }: { algo?: Algo }) {
  const [arr, setArr] = useState<number[]>([]);
  const [steps, setSteps] = useState<Step[]>([]);
  const [idx, setIdx] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(60);
  const timer = useRef<number | null>(null);

  const shuffle = () => {
    const a = Array.from({length: 12}, () => Math.floor(Math.random()*90)+10);
    setArr(a); setSteps(builders[algo](a)); setIdx(0); setPlaying(false);
  };
  useEffect(() => { shuffle(); /* eslint-disable-next-line */ }, [algo]);

  useEffect(() => {
    if (!playing) return;
    if (idx >= steps.length - 1) { setPlaying(false); return; }
    timer.current = window.setTimeout(() => setIdx((i) => i + 1), 600 - speed * 5);
    return () => { if (timer.current) clearTimeout(timer.current); };
  }, [playing, idx, steps.length, speed]);

  const step = steps[idx] ?? { arr, sorted: [] };
  const maxVal = Math.max(...(step.arr.length ? step.arr : [1]));

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 mb-5">
        <button onClick={() => setPlaying(!playing)} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl inline-flex items-center gap-1 hover:scale-105 transition-transform">
          {playing ? <Pause className="h-4 w-4"/> : <Play className="h-4 w-4"/>} {playing ? "Pause" : "Play"}
        </button>
        <button onClick={() => setIdx(Math.min(steps.length-1, idx+1))} className="bg-muted font-bold px-3 py-2 rounded-xl">Step ▸</button>
        <button onClick={() => setIdx(Math.max(0, idx-1))} className="bg-muted font-bold px-3 py-2 rounded-xl">◂ Back</button>
        <button onClick={() => setIdx(0)} className="bg-muted font-bold px-3 py-2 rounded-xl inline-flex items-center gap-1"><RotateCcw className="h-4 w-4"/>Reset</button>
        <button onClick={shuffle} className="bg-brand-yellow text-foreground font-bold px-3 py-2 rounded-xl inline-flex items-center gap-1"><Shuffle className="h-4 w-4"/>Shuffle</button>
        <label className="ml-auto flex items-center gap-2 text-sm">
          Speed
          <input type="range" min={10} max={100} value={speed} onChange={(e)=>setSpeed(+e.target.value)} />
        </label>
      </div>

      <div className="rounded-2xl bg-muted/40 p-4 h-64 flex items-end justify-center gap-1">
        {step.arr.map((v, i) => {
          const isComparing = i === step.a || i === step.b;
          const isSorted = step.sorted.includes(i);
          return (
            <motion.div
              key={i}
              layout
              animate={{ height: `${(v / maxVal) * 100}%` }}
              className={`w-6 sm:w-8 rounded-t-lg ${
                isSorted ? "bg-brand-green" : isComparing ? "bg-brand-yellow" : "bg-gradient-primary"
              } grid place-items-end pb-1 text-white text-xs font-bold`}
            >
              {v}
            </motion.div>
          );
        })}
      </div>
      <div className="mt-3 text-center text-sm text-muted-foreground">
        Step {idx + 1} / {steps.length} · <span className="text-brand-yellow font-bold">yellow</span> = comparing · <span className="text-brand-green font-bold">green</span> = sorted
      </div>
    </div>
  );
}