import { motion } from "framer-motion";

const tree = {
  v: "👴 Grandpa",
  c: [
    { v: "👨 Dad", c: [{ v: "🧒 Me" }, { v: "👶 Sis" }] },
    { v: "👩 Aunt", c: [{ v: "🧑 Cousin" }] },
  ],
};
type Node = { v: string; c?: Node[] };

function Branch({ node, depth = 0 }: { node: Node; depth?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: depth * 0.2 }}
      className="flex flex-col items-center"
    >
      <div className="glass rounded-2xl px-4 py-2 font-bold shadow-soft">{node.v}</div>
      {node.c && (
        <div className="flex gap-6 mt-6 relative">
          {node.c.map((child, i) => (
            <div key={i} className="relative">
              <div className="absolute left-1/2 -top-6 w-px h-6 bg-foreground/30" />
              <Branch node={child} depth={depth + 1} />
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}

export function TreeDemo() {
  return (
    <div className="overflow-auto">
      <div className="flex justify-center py-4 min-w-max">
        <Branch node={tree} />
      </div>
    </div>
  );
}