import { useState } from "react";
import { motion } from "framer-motion";

export function BinarySearchDemo() {
  const arr = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91];
  const [target, setTarget] = useState(23);
  const [lo, setLo] = useState(0);
  const [hi, setHi] = useState(arr.length - 1);
  const [found, setFound] = useState<number | null>(null);
  const [log, setLog] = useState<string[]>([]);

  const reset = () => { setLo(0); setHi(arr.length-1); setFound(null); setLog([]); };

  const step = () => {
    if (lo > hi || found !== null) return;
    const mid = Math.floor((lo + hi) / 2);
    if (arr[mid] === target) { setFound(mid); setLog([...log, `Check middle (${arr[mid]}) → found! 🎉`]); return; }
    if (arr[mid] < target) { setLog([...log, `${arr[mid]} too small → look right`]); setLo(mid+1); }
    else { setLog([...log, `${arr[mid]} too big → look left`]); setHi(mid-1); }
  };

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-5 items-center">
        <label className="text-sm font-semibold">Looking for:</label>
        <select value={target} onChange={(e)=>{setTarget(+e.target.value); reset();}} className="rounded-xl px-3 py-2 bg-muted font-bold">
          {arr.map(v => <option key={v}>{v}</option>)}
        </select>
        <button onClick={step} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl">▸ Next guess</button>
        <button onClick={reset} className="bg-muted font-bold px-4 py-2 rounded-xl">Reset</button>
      </div>
      <div className="flex flex-wrap gap-2 justify-center">
        {arr.map((v, i) => {
          const inRange = i >= lo && i <= hi;
          const mid = Math.floor((lo+hi)/2);
          const isMid = i === mid && found === null && lo <= hi;
          const isFound = found === i;
          return (
            <motion.div key={v} animate={{opacity: inRange||isFound?1:0.25, scale: isMid||isFound?1.1:1}}
              className={`h-14 w-14 rounded-2xl grid place-items-center font-bold text-white shadow-soft ${
                isFound ? "bg-brand-green ring-4 ring-brand-yellow" : isMid ? "bg-brand-yellow text-foreground" : "bg-gradient-primary"
              }`}>
              {v}
            </motion.div>
          );
        })}
      </div>
      <div className="mt-5 glass rounded-2xl p-4 text-sm font-medium min-h-[80px]">
        {log.length === 0 ? <span className="text-muted-foreground">Click "Next guess" to start the hunt!</span>
          : log.map((l, i) => <div key={i}>👉 {l}</div>)}
      </div>
    </div>
  );
}