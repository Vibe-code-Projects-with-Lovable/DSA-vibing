import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight } from "lucide-react";

export function LinkedListDemo() {
  const [nodes, setNodes] = useState<number[]>([7, 3, 9]);
  const [traverseIdx, setTraverseIdx] = useState<number | null>(null);

  const add = () => setNodes([...nodes, Math.floor(Math.random() * 90) + 10]);
  const remove = () => setNodes(nodes.slice(0, -1));

  const traverse = async () => {
    for (let i = 0; i < nodes.length; i++) {
      setTraverseIdx(i);
      await new Promise((r) => setTimeout(r, 600));
    }
    setTraverseIdx(null);
  };

  return (
    <div>
      <div className="flex gap-2 mb-5 flex-wrap">
        <button onClick={add} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl hover:scale-105 transition-transform">+ Add node</button>
        <button onClick={remove} className="bg-muted font-bold px-4 py-2 rounded-xl hover:scale-105 transition-transform">– Remove</button>
        <button onClick={traverse} className="bg-brand-yellow text-foreground font-bold px-4 py-2 rounded-xl hover:scale-105 transition-transform">▶ Traverse</button>
      </div>
      <div className="flex flex-wrap items-center gap-2 min-h-[80px]">
        <AnimatePresence>
          {nodes.map((v, i) => (
            <motion.div
              key={`${i}-${v}`}
              layout
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className="flex items-center gap-2"
            >
              <div className={`h-14 w-14 rounded-2xl grid place-items-center font-bold text-white shadow-soft ${
                traverseIdx === i ? "bg-gradient-warm scale-110 ring-4 ring-brand-yellow" : "bg-gradient-primary"
              }`}>
                {v}
              </div>
              {i < nodes.length - 1 && <ArrowRight className="h-5 w-5 text-muted-foreground" />}
            </motion.div>
          ))}
        </AnimatePresence>
        {nodes.length > 0 && <span className="ml-2 text-sm text-muted-foreground">→ null</span>}
      </div>
    </div>
  );
}