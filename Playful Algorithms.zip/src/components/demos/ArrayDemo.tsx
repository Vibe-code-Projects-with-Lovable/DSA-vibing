import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Minus, Search } from "lucide-react";

export function ArrayDemo() {
  const [arr, setArr] = useState<number[]>([3, 7, 1, 9, 4]);
  const [input, setInput] = useState("");
  const [found, setFound] = useState<number | null>(null);

  const add = () => {
    const n = parseInt(input);
    if (!isNaN(n)) {
      setArr([...arr, n]);
      setInput("");
    }
  };
  const remove = () => setArr(arr.slice(0, -1));
  const search = () => {
    const n = parseInt(input);
    if (isNaN(n)) return;
    const idx = arr.indexOf(n);
    setFound(idx);
    setTimeout(() => setFound(null), 1500);
  };

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-5">
        <input
          type="number"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="number"
          className="rounded-xl px-4 py-2 bg-muted border border-border w-28 text-center font-bold"
        />
        <button onClick={add} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl inline-flex items-center gap-1 hover:scale-105 transition-transform"><Plus className="h-4 w-4" /> Add</button>
        <button onClick={remove} className="bg-muted font-bold px-4 py-2 rounded-xl inline-flex items-center gap-1 hover:scale-105 transition-transform"><Minus className="h-4 w-4" /> Pop</button>
        <button onClick={search} className="bg-brand-yellow text-foreground font-bold px-4 py-2 rounded-xl inline-flex items-center gap-1 hover:scale-105 transition-transform"><Search className="h-4 w-4" /> Find</button>
      </div>
      <div className="flex flex-wrap gap-2 min-h-[80px] items-center">
        <AnimatePresence>
          {arr.map((v, i) => (
            <motion.div
              key={`${i}-${v}`}
              layout
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className={`relative h-16 w-16 rounded-2xl grid place-items-center font-bold text-xl text-white shadow-soft ${
                found === i ? "bg-gradient-warm ring-4 ring-brand-yellow scale-110" : "bg-gradient-primary"
              }`}
            >
              {v}
              <span className="absolute -bottom-5 text-xs text-muted-foreground font-medium">[{i}]</span>
            </motion.div>
          ))}
        </AnimatePresence>
        {arr.length === 0 && <span className="text-muted-foreground">Empty array — add some boxes!</span>}
      </div>
    </div>
  );
}