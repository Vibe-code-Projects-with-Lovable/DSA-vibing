import { motion } from "framer-motion";

const nodes = [
  { id: "A", x: 100, y: 60, e: "🏙️" },
  { id: "B", x: 280, y: 50, e: "🌆" },
  { id: "C", x: 380, y: 180, e: "🏖️" },
  { id: "D", x: 200, y: 220, e: "🏞️" },
  { id: "E", x: 50, y: 200, e: "🌋" },
];
const edges = [["A","B"],["A","D"],["B","C"],["C","D"],["D","E"],["A","E"]];

export function GraphDemo() {
  return (
    <div className="rounded-2xl bg-muted/40 p-2">
      <svg viewBox="0 0 460 280" className="w-full h-auto">
        {edges.map(([a,b],i) => {
          const na = nodes.find(n=>n.id===a)!, nb = nodes.find(n=>n.id===b)!;
          return <motion.line key={i} x1={na.x} y1={na.y} x2={nb.x} y2={nb.y}
            stroke="currentColor" strokeWidth="3" strokeLinecap="round"
            className="text-foreground/30"
            initial={{pathLength:0}} animate={{pathLength:1}} transition={{duration:1, delay:i*0.1}}/>;
        })}
        {nodes.map((n,i) => (
          <motion.g key={n.id} initial={{scale:0}} animate={{scale:1}} transition={{delay:0.5 + i*0.1, type:"spring"}}>
            <circle cx={n.x} cy={n.y} r="26" className="fill-[color:var(--brand-purple)]" />
            <text x={n.x} y={n.y+6} textAnchor="middle" className="text-xl">{n.e}</text>
            <text x={n.x} y={n.y+44} textAnchor="middle" className="fill-current font-bold text-sm">{n.id}</text>
          </motion.g>
        ))}
      </svg>
    </div>
  );
}