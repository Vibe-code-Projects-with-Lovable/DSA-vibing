import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const kids = ["👧", "👦", "🧒", "👶", "🧑", "👩"];

export function QueueDemo() {
  const [q, setQ] = useState<{ id: number; face: string }[]>([
    { id: 1, face: kids[0] },
    { id: 2, face: kids[1] },
    { id: 3, face: kids[2] },
  ]);
  const [next, setNext] = useState(4);
  const enqueue = () => {
    setQ([...q, { id: next, face: kids[next % kids.length] }]);
    setNext(next + 1);
  };
  const dequeue = () => setQ(q.slice(1));

  return (
    <div>
      <div className="flex gap-2 mb-5">
        <button onClick={enqueue} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl hover:scale-105 transition-transform">+ Enqueue</button>
        <button onClick={dequeue} className="bg-muted font-bold px-4 py-2 rounded-xl hover:scale-105 transition-transform">– Dequeue 🍦</button>
      </div>
      <div className="rounded-2xl bg-muted/40 p-6 min-h-[140px]">
        <div className="flex items-center gap-2">
          <span className="text-3xl">🍦</span>
          <AnimatePresence mode="popLayout">
            {q.map((p) => (
              <motion.div
                key={p.id}
                layout
                initial={{ x: 50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -50, opacity: 0, scale: 0.5 }}
                className="text-4xl"
              >
                {p.face}
              </motion.div>
            ))}
          </AnimatePresence>
          {q.length === 0 && <span className="text-muted-foreground">Line is empty!</span>}
        </div>
        <div className="mt-4 flex justify-between text-xs text-muted-foreground">
          <span>↑ front (gets served)</span>
          <span>back (new kids join) ↑</span>
        </div>
      </div>
    </div>
  );
}