import { motion } from "framer-motion";
import { useState } from "react";

function heapify(arr: number[]) {
  const a = [...arr];
  for (let i = Math.floor(a.length/2) - 1; i >= 0; i--) sink(a, i, a.length);
  return a;
}
function sink(a: number[], i: number, n: number) {
  while (true) {
    const l = 2*i+1, r = 2*i+2; let max = i;
    if (l < n && a[l] > a[max]) max = l;
    if (r < n && a[r] > a[max]) max = r;
    if (max === i) break;
    [a[i], a[max]] = [a[max], a[i]]; i = max;
  }
}

export function HeapDemo() {
  const [arr, setArr] = useState(heapify([3, 9, 2, 7, 5, 1, 8]));
  const add = () => setArr(heapify([...arr, Math.floor(Math.random()*20)+1]));
  const pop = () => setArr(heapify(arr.slice(1)));

  const levels: number[][] = [];
  let i = 0, size = 1;
  while (i < arr.length) { levels.push(arr.slice(i, i+size)); i += size; size *= 2; }

  return (
    <div>
      <div className="flex gap-2 mb-5">
        <button onClick={add} className="bg-gradient-primary text-white font-bold px-4 py-2 rounded-xl">+ Add</button>
        <button onClick={pop} className="bg-muted font-bold px-4 py-2 rounded-xl">– Pop king 👑</button>
      </div>
      <div className="flex flex-col items-center gap-3 py-2">
        {levels.map((lvl, li) => (
          <div key={li} className="flex gap-3">
            {lvl.map((v, vi) => (
              <motion.div key={`${li}-${vi}-${v}`} layout
                initial={{scale:0}} animate={{scale:1}}
                className={`h-12 w-12 rounded-full grid place-items-center font-bold text-white shadow-soft ${
                  li === 0 ? "bg-gradient-warm ring-4 ring-brand-yellow" : "bg-gradient-primary"
                }`}>
                {v}
              </motion.div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}