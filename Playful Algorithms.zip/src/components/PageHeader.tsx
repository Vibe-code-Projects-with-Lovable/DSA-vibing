import { motion } from "framer-motion";

export function PageHeader({
  emoji,
  title,
  subtitle,
}: {
  emoji?: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="text-center mb-10">
      {emoji && (
        <motion.div
          initial={{ scale: 0, rotate: -30 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 200 }}
          className="text-6xl mb-4 inline-block"
        >
          {emoji}
        </motion.div>
      )}
      <h1 className="text-4xl md:text-6xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>
        <span className="text-gradient-primary">{title}</span>
      </h1>
      {subtitle && (
        <p className="mt-3 text-muted-foreground max-w-2xl mx-auto text-lg">{subtitle}</p>
      )}
    </div>
  );
}

export function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold mb-3" style={{ fontFamily: "Fredoka, sans-serif" }}>{title}</h2>
      <div className="glass-strong rounded-3xl p-6">{children}</div>
    </section>
  );
}

export function PageShell({ children }: { children: React.ReactNode }) {
  return <div className="max-w-5xl mx-auto px-4 lg:px-8 py-10">{children}</div>;
}